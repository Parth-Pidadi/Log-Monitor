import React, { useState } from 'react';
import SearchBox from './SearchBox';


function App() {
  

  return (
    <div className="App">
      <h1 style={{ marginLeft: '10%' }}>Log Monitor</h1>
      <SearchBox />
    </div>
  );
}

export default App;
